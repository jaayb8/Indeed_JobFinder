from django.shortcuts import render
import schedule
import time
from bs4 import BeautifulSoup
import requests
import os
from .models import Record
from django.core.paginator import Paginator
from django.http import HttpResponse
import pymysql.cursors
# from .db_connect import store_data
import mysql.connector
import logging
logger = logging.getLogger('django')

def record_lists(request):
    # Getting data and adding pagination and page range
    all_records = Record.objects.all().order_by('id')
    paginator = Paginator(all_records,8)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    index = page_obj.number - 1 
    max_index = len(paginator.page_range)
    start_index = index - 3 if index >= 3 else 0
    end_index = index + 3 if index <= max_index - 3 else max_index
    page_range = list(paginator.page_range)[start_index:end_index]
    return render(request,'Job_Finder\home.html',{'page_obj':page_obj,'page_range': page_range})
   
def scheduled_scrap(): 
    page=1
    source=requests.get("https://www.indeed.com/jobs?q=data+scientist&start={}".format(page)).text
    soup=BeautifulSoup(source,"lxml")
    for jobs in soup.find_all(class_="result"):
        job_title=jobs.h2.text.strip() if True else None
        company=jobs.span.text.strip() if True else None
        salary=jobs.find('span',class_="no-wrap")
        if salary :
            salary = salary.text.strip() 
        else:
            salary = None  
        # Connecting db and pushing data 
        db_conn = mysql.connector.connect(host ='localhost',user ='root',password ='root',database ='record',auth_plugin='mysql_native_password')
        cursor = db_conn.cursor()
        logger.info("Database connected Successfully ")
        sql = """INSERT INTO scrapaap_record(Job_Title, Company, Salary) VALUES (%s, %s, %s) """ 
        cursor.execute(sql, (job_title,company,salary))   
        db_conn.commit()   

## scheduler code   
schedule.every(2).seconds.do(scheduled_scrap)  
for i in range (2): 
    schedule.run_pending()
    time.sleep(1)       
