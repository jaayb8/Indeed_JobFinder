import unittest
from django.http import HttpResponse

class TestData(unittest.TestCase):
    def test_record_lists(self):
        url = "http://127.0.0.1:8000" 
        data = {    }
        headers = {
            'Content-Type': "application/json",
            'Cache-Control': "no-cache",
            }
        self.assertEqual(url,url)
if __name__ == '__main__':
    unittest.main()