class PageNotFoundError(Exception):
    def __init__(self,  message="Page is not Found"):
        self.message = message
        super().__init__(self.message)

class SalaryNotFoundError(Exception):
   
    def __init__(self, message="Salary is not Found"):
        self.message = message
        super().__init__(self.message)