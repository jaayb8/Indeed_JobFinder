from django.apps import AppConfig


class Job_FinderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Job_Finder'
