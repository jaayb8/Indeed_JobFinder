# from datetime import datetime
# from apscheduler.schedulers.background import BackgroundScheduler
# from .views import scheduled_scrap

# def start():
#     scheduler = BackgroundScheduler()
#     scheduler.add_job(scheduled_scrap, 'interval', seconds=1)
#     scheduler.start()