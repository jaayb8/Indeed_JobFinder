# import mysql.connector
# import logging
# logger = logging.getLogger('django')

# def store_data():
#     try:
#         db_conn = mysql.connector.connect(host ='localhost',user ='root',password ='root',database ='record')
#     except Exception:
#         logger.error("Database Not Found")
#         #Cursor to the database
#         cursor = db_conn.cursor()
#         logger.info("Database connected Successfully ")
#         sql = """INSERT INTO scrapaap_record(Job_Title, Company, Salary) VALUES (%s, %s, %s) """ 
#         cursor.execute(sql, (Job_Title,Company,Salary)) 
#         db_conn.commit() 
# # db_conn.close()
# # #from typing import List
# # import logging
# # #from django.conf import settings
# # from .models import Record
# # logger = logging.getLogger('django')

# # class InsertData:
# #     def store_data(self, record_list: list):
# #         try:
# #             Record.objects.bulk_create(record_list)
# #         except Exception:
# #             logger.error("Database Not Found")